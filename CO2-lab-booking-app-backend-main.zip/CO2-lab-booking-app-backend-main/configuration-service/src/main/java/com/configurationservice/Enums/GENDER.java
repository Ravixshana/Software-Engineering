package com.configurationservice.Enums;

public enum GENDER {
    MALE,
    FEMALE,
    OTHER


}
