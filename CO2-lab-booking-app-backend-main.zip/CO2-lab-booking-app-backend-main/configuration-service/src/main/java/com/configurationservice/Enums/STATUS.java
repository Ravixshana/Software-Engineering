package com.configurationservice.Enums;

public enum STATUS {
    ACTIVE,
    INACTIVE,
    ARCHIVED


}
