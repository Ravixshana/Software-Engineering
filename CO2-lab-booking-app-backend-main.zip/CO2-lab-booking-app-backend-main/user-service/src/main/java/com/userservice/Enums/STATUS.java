package com.userservice.Enums;

public enum STATUS {
    ACTIVE,
    INACTIVE,
    ARCHIVED


}
