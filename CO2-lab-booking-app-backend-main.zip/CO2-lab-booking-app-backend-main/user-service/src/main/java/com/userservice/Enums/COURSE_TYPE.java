package com.userservice.Enums;

public enum COURSE_TYPE {
    TECHNICAL,
    NON_TECHNICAL
}
