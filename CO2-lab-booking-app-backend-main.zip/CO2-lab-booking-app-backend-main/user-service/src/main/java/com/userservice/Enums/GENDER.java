package com.userservice.Enums;

public enum GENDER {
    MALE,
    FEMALE,
    OTHER


}
