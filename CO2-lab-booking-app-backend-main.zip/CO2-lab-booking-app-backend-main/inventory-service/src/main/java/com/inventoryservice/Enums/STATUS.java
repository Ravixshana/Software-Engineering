package com.inventoryservice.Enums;

public enum STATUS {
    ACTIVE,
    INACTIVE,
    ARCHIVED


}
