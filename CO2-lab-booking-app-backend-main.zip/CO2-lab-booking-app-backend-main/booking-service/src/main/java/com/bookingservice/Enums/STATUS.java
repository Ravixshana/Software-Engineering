package com.bookingservice.Enums;

public enum STATUS {
    ACTIVE,
    INACTIVE,
    ARCHIVED


}
