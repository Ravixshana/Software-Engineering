package com.bookingservice.Enums;

public enum GENDER {
    MALE,
    FEMALE,
    OTHER


}
