package com.bookingservice.Enums;

public enum TIME_SLOT {
    TS_08_00,
    TS_08_30,
    TS_09_00,
    TS_09_30,
    TS_10_00,
    TS_10_30,
    TS_11_00,
    TS_11_30,
    TS_12_00,
    TS_12_30,
    TS_13_00,
    TS_13_30,
    TS_14_00,
    TS_14_30,
    TS_15_00,
    TS_15_30,
    TS_16_00,
    TS_16_30,
    TS_17_00


}
