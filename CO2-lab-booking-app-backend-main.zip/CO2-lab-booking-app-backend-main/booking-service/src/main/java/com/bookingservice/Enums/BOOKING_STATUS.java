package com.bookingservice.Enums;

public enum BOOKING_STATUS {
    PENDING,
    APPROVED,
    REJECTED


}
