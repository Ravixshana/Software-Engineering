package com.bookingservice.Enums;

public enum COURSE_TYPE {
    TECHNICAL,
    NON_TECHNICAL
}
